#This is a Bash script that can used to compile and run all the test cases
#Made to make automated testing easier
#Please keep all the sample input txt files in their original directories or else this breaks

#All of these commands can be run right after each other by using:
#bash test_all.sh
#In a Linux or WSL terminal (will not work on host Windows)

echo "Compiling game..."
g++ -o piggy_game bank.cpp
echo "Done! Running Test Case 1"
./piggy_game < ./sample_input/input1.txt > test_output1.txt
echo "Done! Running Test Case 2"
./piggy_game < ./sample_input/input2.txt > test_output2.txt
echo "Done! Running Test Case with Bad Data"
./piggy_game < ./sample_input/bad_data.txt > test_bad_data_output.txt
echo "Done! Running Test Case with Many Games"
./piggy_game < ./sample_input/addicted.txt > test_addicted_output.txt
rm piggy_game